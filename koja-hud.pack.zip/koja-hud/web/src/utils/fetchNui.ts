import { isEnvBrowser } from './misc';

type NuiWindow = Window & { GetParentResourceName?: () => string };

export async function fetchNui<T = unknown>(eventName: string, data?: unknown, mock?: { data: T; delay?: number }): Promise<T> {
  if (isEnvBrowser()) {
    if (!mock) return new Promise<T>(() => undefined);
    await new Promise((resolve) => setTimeout(resolve, mock.delay));
    return mock.data;
  }

  const nuiWindow = window as NuiWindow;
  const resourceName = nuiWindow.GetParentResourceName ? nuiWindow.GetParentResourceName() : 'nui-frame-app';

  const resp = await fetch(`https://${resourceName}/${eventName}`, {
    method: 'post',
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
    },
    body: JSON.stringify(data ?? {}),
  });

  return resp.json() as Promise<T>;
}
