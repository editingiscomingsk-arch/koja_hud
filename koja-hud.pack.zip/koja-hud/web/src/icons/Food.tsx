import React, { useId } from "react";

interface FoodProps {
    fillPercentage: number;
    color: string;
}

const Food: React.FC<FoodProps> = ({ fillPercentage = 50, color }) => {
    const gradientId = useId();
    const gradientOffset = `${fillPercentage}%`;

    return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" className="size-6">
            <defs>
                <linearGradient id={gradientId} x1="0%" y1="100%" x2="0%" y2="0%">
                    <stop offset={gradientOffset} style={{ stopColor: color, stopOpacity: 0.7 }} />
                    <stop offset="0%" style={{ stopColor: color, stopOpacity: 0.2 }} />
                </linearGradient>
            </defs>
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <path d="M4 11.319c0 3.102 .444 5.319 2.222 7.978c1.351 1.797 3.156 2.247 5.08 .988c.426 -.268 .97 -.268 1.397 0c1.923 1.26 3.728 .809 5.079 -.988c1.778 -2.66 2.222 -4.876 2.222 -7.977c0 -2.661 -1.99 -5.32 -4.444 -5.32c-1.267 0 -2.41 .693 -3.22 1.44a.5 .5 0 0 1 -.672 0c-.809 -.746 -1.953 -1.44 -3.22 -1.44c-2.454 0 -4.444 2.66 -4.444 5.319" fill={`url(#${gradientId})`} stroke={color} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M7 12c0 -1.47 .454 -2.34 1.5 -3" fill={`url(#${gradientId})`} stroke={color} strokeWidth=".8" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 7c0 -1.2 .867 -4 3 -4" fill={`url(#${gradientId})`} stroke={color} strokeWidth=".8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    );
};

export default Food;
