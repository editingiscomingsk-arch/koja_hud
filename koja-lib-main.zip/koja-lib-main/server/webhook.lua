KOJA.Server.Webhooks = {
    ['cardealer'] = ''
}